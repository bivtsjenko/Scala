package controllers

import models.ResponseDataFuture
import models.OcrFormats._
import models.{CertusOcrRepository, Ocr}
import org.mockito.Mockito._
import org.scalatest.mockito.MockitoSugar
import org.scalatest.{MustMatchers, OptionValues, WordSpec}
import org.scalatestplus.play.WsScalaTestClient
import play.api.inject.bind
import play.api.inject.guice.GuiceApplicationBuilder
import play.api.libs.json._
import play.api.mvc.{AnyContentAsEmpty, Result}
import play.api.test.FakeRequest
import play.api.test.Helpers.{GET, route, status, _}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/**
  * Class CertusOcrControllerSpec
  */
class CertusOcrControllerSpec extends WordSpec with MustMatchers with OptionValues with WsScalaTestClient with MockitoSugar {

  private val baseUri = "/events/v1/certus"
  private val baseJson = "{\"property\": [],\"lane\": {\"id\": 1,\"processPointId\": 990001,\"supplierId\": 1,\"name\": \"Lane0001\",\"site\": \"Default\",\"created\": \"2017-10-11T15:49:46.700Z\",\"changed\": \"2017-10-11T15:49:46.700Z\",\"createdBy\": \"GateOcr\",\"changedBy\": \"GateOcr\"},\"vehicle\": {\"property\": [{\"value\": \"11\",\"id\": 44,\"name\": \"ResultCode\",\"created\": \"2017-11-27T13:49:35.996Z\",\"createdBy\": \"GateOcr\"}],\"licensePlate\": \"NL123A\",\"value\": [{\"value\": \"NL123A\",\"id\": 27,\"name\": \"LicensePlate\",\"created\": \"2017-11-27T13:49:36.12Z\",\"createdBy\": \"GateOcr\",\"confidence\": 95,\"location\": \"\",\"image\": \"http://CP-ESXISRV01:9998/ocr/19/images/Temp1_CarRightUpper.jpg\"}],\"id\": 19},\"container\": [{\"property\": [{\"value\": \"11\",\"id\": 44,\"name\": \"ResultCode\",\"created\": \"2017-11-27T13:49:35.996Z\",\"createdBy\": \"GateOcr\"},{\"value\": \"Matching is disabled. Original OCR data is reported.\",\"id\": 45,\"name\": \"ResultText\",\"created\": \"2017-11-27T13:49:36.12Z\",\"createdBy\": \"GateOcr\"}],\"code\": \"TEST1234567\",\"value\": [{\"value\": \"TEST1234567\",\"id\": 42,\"name\": \"ContainerCode\",\"created\": \"2017-11-27T13:49:35.996Z\",\"createdBy\": \"GateOcr\",\"confidence\": 100,\"location\": \"\",\"image\": \"http://CP-ESXISRV01:9998/ocr/19/images/Temp1_ContRightUpper_f.jpg\"},{\"value\": \"22R3\",\"id\": 43,\"name\": \"IsoCode\",\"created\": \"2017-11-27T13:49:35.996Z\",\"createdBy\": \"GateOcr\",\"confidence\": 100,\"location\": \"\",\"image\": \"http://CP-ESXISRV01:9998/ocr/19/images/\"}],\"id\": 19,\"index\": 1}],\"trailer\": [{\"property\": [{\"value\": \"0\",\"id\": 9,\"name\": \"ResultCode\",\"created\": \"2017-11-27T13:49:36.12Z\",\"createdBy\": \"GateOcr\"},{\"value\": \"Number NL123A was matched.\",\"id\": 10,\"name\": \"ResultText\",\"created\": \"2017-11-27T13:49:36.12Z\",\"createdBy\": \"GateOcr\"}],\"licensePlate\": \"NL123A\",\"value\": [{\"value\": \"NL123A\",\"id\": 5,\"name\": \"LicensePlate\",\"created\": \"2017-11-27T13:49:36.12Z\",\"createdBy\": \"GateOcr\",\"confidence\": 95,\"location\": \"\",\"image\": \"http://CP-ESXISRV01:9998/ocr/19/images/Temp1_CarRearRight.jpg\"}],\"id\": 5,\"index\": 1}],\"messageTimestamp\": [{\"messageId\": \"341b8bf3-8228-4692-ac37-97aa68745734\",\"name\": \"HTS_GATE\",\"timestamp\": \"2017-11-27T13:49:36.12Z\"}],\"id\": 19,\"detected\": \"2017-11-27T13:49:35.00Z\",\"created\": \"2017-11-27T13:49:35.981Z\",\"changed\": \"2017-11-27T13:49:35.981Z\",\"createdBy\": \"GateOcr\",\"changedBy\": \"GateOcr\"\n}"
  private val parsedJson = Json.parse(baseJson)

  private val mockedRepo = mock[CertusOcrRepository]
  private val mockedApp = new GuiceApplicationBuilder().overrides(bind[CertusOcrRepository].toInstance(mockedRepo)).build()

  def createDataSet(base: JsValue, data: Seq[(String, JsValue)]): Seq[Ocr] = {
    data.map(f => {
      base.transform(__.json.update(
        __.read[JsObject].map { o => o ++ JsObject(Seq(f)) }
      )).get
    }).map(f => Json.fromJson[Ocr](f).get)
  }

  def validateHeader(eventualResult: Future[Result], next: Option[String], self: String, limit: String, total: String, offset: String) = {
    if (next.isDefined) {
      header("X-Next", eventualResult).get mustBe next.get
    }
    header("X-Self", eventualResult).get mustBe self
    header("X-Limit", eventualResult).get mustBe limit
    header("X-Total", eventualResult).get mustBe total
    header("X-Offset", eventualResult).get mustBe offset
  }

  "Get events for lanes" should {

    val laneUri = (offset: Int, limit: Int, lane: Int) => s"$baseUri/lane?offset=$offset&limit=$limit&lane=$lane"

    "When single available" in {
      reset(mockedRepo)
      val input: Seq[(String, JsNumber)] = Seq("id" -> JsNumber(42))
      val dataSet: Seq[Ocr] = createDataSet(parsedJson, input)

      when(mockedRepo.getPageOnLane(0, 10, 1)).thenReturn(ResponseDataFuture[Ocr](Future {
        1
      }, Future {
        Seq[Ocr](dataSet.head)
      }))
      val request: FakeRequest[AnyContentAsEmpty.type] = FakeRequest(GET, laneUri(0, 10, 1))
      val eventualResult: Future[Result] = route(mockedApp, request).get
      status(eventualResult) must be(200)
      Json.fromJson[Seq[Ocr]](contentAsJson(eventualResult)).get.length must be(1)
      validateHeader(eventualResult, None, "/events/v1/certus/lane?lane=1", "10", "1", "0")
    }

    "When single available and offset too big" in {
      reset(mockedRepo)
      when(mockedRepo.getPageOnLane(10, 10, 1)).thenReturn(ResponseDataFuture[Ocr](Future {
        1
      }, Future {
        Seq.empty[Ocr]
      }))
      val request: FakeRequest[AnyContentAsEmpty.type] = FakeRequest(GET, laneUri(10, 10, 1))
      val eventualResult: Future[Result] = route(mockedApp, request).get
      status(eventualResult) must be(200)
      Json.fromJson[Seq[Ocr]](contentAsJson(eventualResult)).get.length must be(0)
      validateHeader(eventualResult, None, "/events/v1/certus/lane?offset=10&lane=1", "10", "1", "10")
    }

    "No results are available" in {
      reset(mockedRepo)
      when(mockedRepo.getPageOnLane(0, 10, 1)).thenReturn(ResponseDataFuture[Ocr](Future {
        0
      }, Future {
        Seq.empty[Ocr]
      }))
      val request: FakeRequest[AnyContentAsEmpty.type] = FakeRequest(GET, laneUri(0, 10, 1))
      val eventualResult: Future[Result] = route(mockedApp, request).get
      status(eventualResult) must be(404)
    }

    "When multiple results are available" in {
      reset(mockedRepo)
      val events = (1 to 22).map("id" -> JsNumber(_))
      val dataset = createDataSet(parsedJson, events)

      //Start
      val ds1 = dataset.takeRight(10)
      when(mockedRepo.getPageOnLane(0, 10, 42)).thenReturn(ResponseDataFuture(Future {
        dataset.length
      }, Future {
        ds1
      }))
      val eventualResult: Future[Result] = route(mockedApp, FakeRequest(GET, laneUri(0, 10, 42))).get
      status(eventualResult) must be(200)
      Json.fromJson[Seq[Ocr]](contentAsJson(eventualResult)).get.length must be(10)
      validateHeader(eventualResult, Some("/events/v1/certus/lane?offset=10&lane=42"), "/events/v1/certus/lane?lane=42", "10", "22", "0")

      //Follow next
      val ds2 = dataset.dropRight(10).takeRight(10)
      when(mockedRepo.getPageOnLane(10, 10, 42)).thenReturn(ResponseDataFuture(Future {
        dataset.length
      }, Future {
        ds2
      }))
      val nextResult: Future[Result] = route(mockedApp, FakeRequest(GET, header("X-Next", eventualResult).get)).get
      status(nextResult) must be(200)
      Json.fromJson[Seq[Ocr]](contentAsJson(nextResult)).get.length must be(10)
      validateHeader(nextResult, Some("/events/v1/certus/lane?offset=20&lane=42"), "/events/v1/certus/lane?offset=10&lane=42", "10", "22", "10")

      //Follow next
      val ds3 = dataset.dropRight(20).takeRight(10)
      when(mockedRepo.getPageOnLane(20, 10, 42)).thenReturn(ResponseDataFuture(Future {
        dataset.length
      }, Future {
        ds3
      }))
      val nextResult2: Future[Result] = route(mockedApp, FakeRequest(GET, header("X-Next", nextResult).get)).get
      status(nextResult2) must be(200)
      Json.fromJson[Seq[Ocr]](contentAsJson(nextResult2)).get.length must be(2)
      validateHeader(nextResult2, None, "/events/v1/certus/lane?offset=20&lane=42", "10", "22", "20")
    }

  }

  "Get event for OcrId" should {

    val ocrIdUri = (id: Int) => s"$baseUri/ocrid?&ocrId=$id"

    "Record available" in {
      reset(mockedRepo)
      val input: Seq[(String, JsValue)] = Seq("id" -> JsNumber(42))
      val dataSet: Seq[Ocr] = createDataSet(parsedJson, input)

      when(mockedRepo.getByOcrId(42)).thenReturn(Future {
        Some(dataSet.head)
      })
      val request: FakeRequest[AnyContentAsEmpty.type] = FakeRequest(GET, ocrIdUri(42))
      val eventualResult: Future[Result] = route(mockedApp, request).get
      status(eventualResult) must be(200)
      val ocr: Ocr = Json.fromJson[Ocr](contentAsJson(eventualResult)).get
      ocr.id must be(42)
      ocr.messageTimestamp.head.messageId.get must be("341b8bf3-8228-4692-ac37-97aa68745734")
    }

    "No record available" in {
      reset(mockedRepo)
      when(mockedRepo.getByOcrId(42)).thenReturn(Future {
        None
      })
      val request: FakeRequest[AnyContentAsEmpty.type] = FakeRequest(GET, ocrIdUri(42))
      val eventualResult: Future[Result] = route(mockedApp, request).get
      status(eventualResult) must be(404)
    }

  }

  "Get events from timestamp" should {

    val fromDateUri = (offset: Int, limit: Int, timestamp: Int) => s"$baseUri/date?timestamp=$timestamp&limit=$limit&offset=$offset"

    "Positive and negative numbers are allowed" in {
      reset(mockedRepo)
      val input: Seq[(String, JsValue)] = Seq("id" -> JsNumber(42))
      val dataSet: Seq[Ocr] = createDataSet(parsedJson, input)

      //m2 expects ("this", "that") returning "the other"
      when(mockedRepo.getPageByDate(0, 10, -1)).thenReturn(ResponseDataFuture(Future {
        1
      }, Future {
        dataSet
      }))

      status(route(mockedApp, FakeRequest(GET, fromDateUri(0, 10, -1))).get) must be(200)

      when(mockedRepo.getPageByDate(0, 10, Int.MaxValue - 1)).thenReturn(ResponseDataFuture(Future {
        1
      }, Future {
        dataSet
      }))
      status(route(mockedApp, FakeRequest(GET, fromDateUri(0, 10, Int.MaxValue - 1))).get) must be(200)
    }

    "Offset past last record" in {
      reset(mockedRepo)
      val events = (1 to 5).map("id" -> JsNumber(_))
      val dataset = createDataSet(parsedJson, events)

      when(mockedRepo.getPageByDate(10, 10, 1)).thenReturn(ResponseDataFuture(Future {
        5
      }, Future {
        Seq.empty[Ocr]
      }))
      val result = route(mockedApp, FakeRequest(GET, fromDateUri(10, 10, 1))).get
      println(await(result))
      status(result) must be(200)
      validateHeader(result, None, "/events/v1/certus/date?offset=10&timestamp=1", "10", "5", "10")
    }

    "When non default limit for first page this is in the self uri" in {
      reset(mockedRepo)
      val events = (1 to 20).map("id" -> JsNumber(_))
      val dataset = createDataSet(parsedJson, events)

      when(mockedRepo.getPageByDate(10, 15, 1)).thenReturn(ResponseDataFuture(Future {
        5
      }, Future {
        Seq.empty[Ocr]
      }))
      val result = route(mockedApp, FakeRequest(GET, fromDateUri(10, 15, 1))).get
      println(await(result))
      status(result) must be(200)
      validateHeader(result, None, "/events/v1/certus/date?offset=10&limit=15&timestamp=1", "15", "5", "10")
    }

    "No result available" in {
      reset(mockedRepo)
      when(mockedRepo.getPageByDate(0, 15, 1)).thenReturn(ResponseDataFuture(Future {
        0
      }, Future {
        Seq.empty[Ocr]
      }))
      val result = route(mockedApp, FakeRequest(GET, fromDateUri(0, 15, 1))).get
      status(result) must be(404)
    }

  }


