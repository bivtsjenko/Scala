package repos
import java.sql.Timestamp
import java.text.SimpleDateFormat

import javax.inject.Inject
import play.api.Logger
import play.modules.reactivemongo.ReactiveMongoApi
import play.modules.reactivemongo.json._
import reactivemongo.api.commands.WriteResult
import reactivemongo.play.json.collection.JSONCollection

import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

case class ContainerFields(timestamp: Timestamp, containerNumber: String, containerType: String, loaded: String, transportType: String, direction: String, identifier: String)

trait WidgetRepo {
//  def find()(implicit ec: ExecutionContext): Future[List[JsObject]]
//  def select(selector: BSONDocument)(implicit ec: ExecutionContext): Future[Option[JsObject]]
//  def update(selector: BSONDocument, update: BSONDocument)(implicit ec: ExecutionContext): Future[WriteResult]
//  def remove(document: BSONDocument)(implicit ec: ExecutionContext): Future[WriteResult]
//  def save(document: BSONDocument)(implicit ec: ExecutionContext): Future[WriteResult]
  def store(widgetsFieldss: ContainerFields)(implicit ec: ExecutionContext): Future[WriteResult]
  def find(timestamp: Timestamp, containerNumber: String): Future[Option[ContainerFields]]
  def find_t(timestamp: Timestamp): Future[Option[ContainerFields]]

}



object TimeContainerModel {

  import play.api.libs.json._


  implicit object timestampFormat extends Format[Timestamp] {
    val format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")

    def reads(json: JsValue): JsSuccess[Timestamp] = {
      val str = json.as[String]
      JsSuccess(Try(new Timestamp(format.parse(str).getTime)).getOrElse(new Timestamp(0)))
    }

    def writes(ts: Timestamp) = JsString(format.format(ts))
  }

  implicit val TimeContainerFormat: OFormat[ContainerFields] = Json.format[ContainerFields]


}

class WidgetRepoImpl @Inject() (reactiveMongoApi: ReactiveMongoApi)(implicit ec: ExecutionContext) extends WidgetRepo {
  import play.api.libs.json._
  import TimeContainerModel._

  private val logger = Logger(this.getClass)
  implicit lazy val ContainerCollection: Future[JSONCollection] = reactiveMongoApi.database.map(_.collection[JSONCollection]("ContainerRepo"))

  def store(containerFields: ContainerFields)(implicit ec: ExecutionContext): Future[WriteResult] = ContainerCollection.flatMap(_.insert(containerFields))

  override def find(timestamp: Timestamp, containerNumber: String): Future[Option[ContainerFields]] = {

    val jsObject = Json.obj("timestamp" -> timestampFormat.writes(timestamp), "containerNumber" -> JsString(containerNumber))
    ContainerCollection.flatMap(
      _.find(jsObject).requireOne[ContainerFields]
        .map(Option[ContainerFields])
        .recover {
          case _ =>
            logger.warn(s"Unable to get movement with timestamp or container number: ")
            None
        })
  }

  override def find_t(timestamp: Timestamp): Future[Option[ContainerFields]] = {

    val jsObject = Json.obj("timestamp" -> timestampFormat.writes(timestamp))
    ContainerCollection.flatMap(
      _.find(jsObject).requireOne[ContainerFields]
        .map(Option[ContainerFields])
        .recover {
          case _ =>
            logger.warn(s"Unable to get movement with timestamp: ")
            None
        })
  }
}



  //  override def select(selector: BSONDocument)(implicit ec: ExecutionContext): Future[Option[JsObject]] = ???


//  override def select()(implicit ec: ExecutionContext): Future[List[JsObject]] = {
//    val genericQueryBuilder = collection.find(Json.obj());
//    val cursor = genericQueryBuilder.cursor[JsObject](ReadPreference.Primary);
//    cursor.collect[List]()
//
//  }




//
//
//  override def select(widgetFields: WidgetsFields)(implicit ec: ExecutionContext): Future[Option[JsObject]] = {
//    collection.find(widgetFields).one[JsObject]
//
//  }
//
//  override def update(selector: BSONDocument, update: BSONDocument)(implicit ec: ExecutionContext): Future[WriteResult] = {
//    collection.update(selector, update)
//  }
//
//  override def remove(document: BSONDocument)(implicit ec: ExecutionContext): Future[WriteResult] = {
//    collection.remove(document)
//  }
//
//  override def save(document: BSONDocument)(implicit ec: ExecutionContext): Future[WriteResult] = {
//    collection.update(BSONDocument("_id" -> document.get("_id").getOrElse(BSONObjectID.generate)), document, upsert = true)
//  }


